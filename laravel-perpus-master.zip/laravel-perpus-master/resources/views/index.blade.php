@extends('layout.main')

@section('title', 'Laravel - SI Perpustakaan')

@section('content')
    <div class="container">
        <div class="jumbotron">
            <h1 class="display-4">Selamat Datang!</h1>
            <p class="lead">Ini adalah contoh sistem informasi perpustakaan sederhana dengan laravel 5.8</p>
            <hr class="my-4">            
        </div>
    </div>
@endsection